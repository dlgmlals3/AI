import numpy as np
import random
from collections import defaultdict
from environment import Env


class SARSAgent:
    def __init__(self, actions):


    # <s, a, r, s', a'>의 샘플로부터 큐함수를 업데이트
    def learn(self, state, action, reward, next_state, next_action):


    # 입실론 탐욕 정책에 따라서 행동을 반환
    def get_action(self, state):



# 큐함수의 값에 따라 최적의 행동을 반환
def arg_max(q_list):


if __name__ == "__main__":
    env = Env()


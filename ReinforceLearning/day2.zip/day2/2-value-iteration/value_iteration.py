import numpy as np
from environment import GraphicDisplay, Env


class ValueIteration:
    def __init__(self, env):

    def value_iteration(self):


    # 현재 가치 함수로부터 행동을 반환
    def get_action(self, state):


    def get_value(self, state):
        return self.value_table[state[0]][state[1]]


if __name__ == "__main__":
    env = Env()
    value_iteration = ValueIteration(env)
    grid_world = GraphicDisplay(value_iteration)
    grid_world.mainloop()
